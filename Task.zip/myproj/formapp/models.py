from django.db import models

class emp(models.Model):
    name = models.CharField(max_length=100)
    Email = models.CharField(max_length=50)
    Contact_Number = models.IntegerField(10)


    class Meta:
        db_table = 'emp';